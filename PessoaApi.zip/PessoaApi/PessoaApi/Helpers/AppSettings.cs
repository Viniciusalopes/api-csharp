namespace PessoaApi.Helpers
{
    public class AppSettings
    {
        public string Secret { get; set; }
    }
}